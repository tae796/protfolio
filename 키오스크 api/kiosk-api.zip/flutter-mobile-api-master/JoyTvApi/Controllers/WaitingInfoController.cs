using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using JoyTvApi.Models;
using JoyTvApi.Models.AgencyTotal;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.Extensions.Logging;

namespace JoyTvApi.Controllers.AgencyTotal
{
    [Route("api/[controller]")]
    [ApiController]
    public class WaitingInfoController : ControllerBase
    {
        private readonly ILogger _logger;
        private readonly JoyTvContext _context;

        public WaitingInfoController(JoyTvContext context)
        {
            _context = context;
        }

        // GET: api/DepositConfirm
        [HttpGet]
        public async Task<ActionResult<IEnumerable<WAITING_INF>>> GetDepositConfirm()
        {
            return await _context.WAITING_INF.ToListAsync();
        }


        // GET: api/DepositConfirm/5
        [HttpGet("{sto_inf_cd}")]

        public async Task<ActionResult<List<WAITING_INF>>> GetDepositConfirm(String sto_inf_cd)
        {
            List<WAITING_INF> depositConfirm = new List<WAITING_INF>();

            try
            {
                depositConfirm = _context.WAITING_INF.Where(x => x.sto_inf_cd == sto_inf_cd).ToList();


            }
            catch
            {

                return NotFound();
            }


            return depositConfirm;

        }




        // GET: api/DepositConfirm/5
        [HttpGet("Waiting/{sto_inf_cd}")]
        //public async Task<ActionResult<List<WAITING_INF>>>
        public Dictionary<String, object> GetWaiting(String sto_inf_cd)
        {
            List<WAITING_INF> depositConfirm = new List<WAITING_INF>();
            Dictionary<String, object> pagingMap = new Dictionary<String, Object>();
            WaitingPaging waitingPaging = new WaitingPaging();

            try
	        {
                depositConfirm = _context.WAITING_INF.FromSqlRaw("select * from WAITING_INF where STO_INF_CD={0} order by WAITING_NUM", sto_inf_cd).ToList();
                //Where(x => x.sto_inf_cd == sto_inf_cd).OrderBy( .ToList();
                
                waitingPaging.list = depositConfirm;
                waitingPaging.CurrentPage = 1;
                waitingPaging.TotalPage = 1;
                waitingPaging.TotalCount = depositConfirm.Count();
                
                pagingMap.Add("WaitingPaging", waitingPaging);
            }
            catch {
                pagingMap = null;
            }
            
            return pagingMap;
        }

        [HttpGet("sto_inf_cd={sto_inf_cd}")]
        public async Task<ActionResult<WAITING_INF>> GetWaiting_num(String sto_inf_cd)
        {

            int maxWaiting_num = 0;
          
            try
            {
                maxWaiting_num = _context.WAITING_INF.Where(y => y.sto_inf_cd == sto_inf_cd)
                    .Max(y => y.Waiting_num);
            }
            catch
            {
                var WAITING_INF = new WAITING_INF();
                WAITING_INF.Date = DateTime.Now;
                WAITING_INF.sto_inf_cd = sto_inf_cd;
                WAITING_INF.Waiting_num = 0;
                WAITING_INF.Id = 1;
                WAITING_INF.Phn_num = "010-0000-0000";
                return WAITING_INF;
            }
            

            List<WAITING_INF> depositConfirm = _context.WAITING_INF.Where(x => x.Waiting_num == maxWaiting_num).ToList();

            return depositConfirm[0];
        }



            // PUT: api/DepositConfirm/5
            // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
            [HttpPut("{id}")]
        public async Task<IActionResult> PutDepositConfirm(int id, WAITING_INF depositConfirm)
        {
            if (id != depositConfirm.Id)
            {
                return BadRequest();
            }

            _context.Entry(depositConfirm).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DepositConfirmExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/DepositConfirm
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<WAITING_INF>> PostDepositConfirm(WAITING_INF depositConfirm)
        {
            List<WAITING_INF> infos = _context.WAITING_INF.Where(x => x.Waiting_num == depositConfirm.Waiting_num && x.sto_inf_cd == depositConfirm.sto_inf_cd).ToList();
            if (infos.Count > 0) return BadRequest();
            List<MEMB_INF> infos2 = _context.MEMB_INF.Where(x => x.Phn_num == depositConfirm.Phn_num).ToList();
            if (infos2.Count == 0)
			{

                MEMB_INF member = new MEMB_INF();
                member.Memb_inf_cd = _context.MEMB.FromSqlRaw("select GET_KEY('MEMBER') as Memb_inf_cd").FirstOrDefault().Memb_inf_cd;

                member.Phn_num = depositConfirm.Phn_num;
                member.Fir_inp_ddt = DateTime.Now;
                member.Las_mod_ddt = DateTime.Now;
                member.Las_mod_pers = "RT2016120118581100765";

                await _context.SaveChangesAsync();
                _context.MEMB_INF.Add(member);
            } 

            depositConfirm.Date = DateTime.Now;

            _context.WAITING_INF.Add(depositConfirm);
            await _context.SaveChangesAsync();

            int maxWaiting_num = 0;
            try
            {
                maxWaiting_num = _context.WAITING_INF.Where(y => y.sto_inf_cd == depositConfirm.sto_inf_cd)
                    .Max(y => y.Waiting_num);
            }
            catch
            {
                maxWaiting_num = 0;
            }

            // return CreatedAtAction("GetDepositConfirm", new { id = depositConfirm.Id }, depositConfirm);
            return CreatedAtAction("GetDepositConfirm", new {id = maxWaiting_num + 1} , depositConfirm);
        }

        //// DELETE: api/DepositConfirm/5
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteDepositConfirm(int id)
        //{
        //    var depositConfirm = await _context.WAITING_INF.FindAsync(id);
        //    if (depositConfirm == null)
        //    {
        //        return NotFound();
        //    }

        //    _context.WAITING_INF.Remove(depositConfirm);
        //    await _context.SaveChangesAsync();

        //    return NoContent();
        //}

        [HttpDelete("Phn_num={phoneNumber}")]
        public void DeletePhoneNumWaiting(string phoneNumber)
        {
            try
            {
                _context.WAITING_INF.RemoveRange(_context.WAITING_INF.Where(x => x.Phn_num == phoneNumber));
                _context.SaveChanges();
            }
            catch {}
        }

        private bool DepositConfirmExists(int id)
        {
            return _context.WAITING_INF.Any(e => e.Id == id);
        }
        
        [HttpDelete("{sto_inf_cd}")]
        public async Task<IActionResult> ResetWaiting(string sto_inf_cd)
        {
            List<WAITING_INF> infos = _context.WAITING_INF.Where(x => x.sto_inf_cd == sto_inf_cd).ToList();
            _context.WAITING_INF.RemoveRange(infos);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
