using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using JoyTvApi.Models;
using JoyTvApi.Models.AgencyTotal;

namespace JoyTvApi.Controllers.AgencyTotal
{
    [Route("api/[controller]")]
    [ApiController]
    public class CouponInfoController : ControllerBase
    {
        private readonly JoyTvContext _context;

        public CouponInfoController(JoyTvContext context)
        {
            _context = context;
        }

        // GET: api/DepositConfirm
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CAMP_INF>>> GetCAMP_INF()
        {


            return await _context.CAMP_INF.ToListAsync();
        }

        [HttpGet("mobile")]
        public IActionResult GetCouponInfo()
        {
            List<CAMP_INF> memberInfos = new List<CAMP_INF>();

            memberInfos = _context.CAMP_INF.Where(x => x.Expr_yn == "N").ToList();

            return Ok(new { results = memberInfos }); ;
        }


        [HttpGet("Camp_inf_cd={Camp_inf_cd}")]
        public async Task<ActionResult<List<CAMP_INF>>> GetCAMP_INF(int Camp_inf_cd)
        {
            List<CAMP_INF> depositConfirm = new List<CAMP_INF>();
            try
            {
                depositConfirm = _context.CAMP_INF.Where(x => x.Camp_inf_cd == Camp_inf_cd).ToList();
            }
            catch
            {

                return NotFound();
            }

            return depositConfirm;
        }

        [HttpGet("Memb_inf_cd={Memb_inf_cd}")]
        public IActionResult GetCouponInfo(String Memb_inf_cd)
        {
            List<CAMP_INF> memberInfos = new List<CAMP_INF>();
            List<CAMP_INF> result = new List<CAMP_INF>();
            List<COUP_INF> couponinfos = new List<COUP_INF>();
            int couponcount;
            COUP_INF coupon = new COUP_INF();

            memberInfos = _context.CAMP_INF.Where(x => x.Expr_yn == "N").ToList();
            couponcount = memberInfos.Count;
            for (int i = 0; i < couponcount; i++)
            {
                coupon = _context.COUP_INF.Where(x => x.Coup_titl == memberInfos[i].Coup_titl && x.Memb_inf_cd == Memb_inf_cd).FirstOrDefault();
                if (coupon == null)
                {
                    result.Add(_context.CAMP_INF.Where(x => x.Coup_titl == memberInfos[i].Coup_titl).FirstOrDefault());
                }
                else
                {

                }
            }


            return Ok(new { results = result }); ;
        }


        // POST: api/DepositConfirm
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<CAMP_INF>> PostCAMP_INF(CAMP_INF depositConfirm)
        {
            List<CAMP_INF> infos = _context.CAMP_INF.Where(x => x.Camp_inf_cd == depositConfirm.Camp_inf_cd).ToList();
            if (infos.Count > 0) return BadRequest();
            _context.CAMP_INF.Add(depositConfirm);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCAMP_INF", new { Camp_inf_cd = depositConfirm.Camp_inf_cd }, depositConfirm);
        }



        private bool DepositConfirmExists(int Camp_inf_cd)
        {
            return _context.CAMP_INF.Any(e => e.Camp_inf_cd == Camp_inf_cd);
        }

    }
}