using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using JoyTvApi.Models;
using JoyTvApi.Models.AgencyTotal;
using Newtonsoft.Json;
using System.Net.Mail;
using System.IO;
using Microsoft.Extensions.Logging;

namespace JoyTvApi.Controllers.AgencyTotal
{
    [Route("api/[controller]")]
    [ApiController]
    public class Memb_infController : ControllerBase
    {
        private readonly JoyTvContext _context;

        public Memb_infController(JoyTvContext context)
        {
            _context = context;
        }

        // GET: api/DepositConfirm
        [HttpGet]
        public async Task<ActionResult<IEnumerable<MEMB_INF>>> GetMEMB_INF()
        {
            return await _context.MEMB_INF.ToListAsync();
        }

        [HttpGet("Memb_inf_cd={Memb_inf_cd}")]
        public async Task<ActionResult<List<MEMB_INF>>> GetMEMB_INF(string Memb_inf_cd)
        {
            List<MEMB_INF> MEMB_INFs = new List<MEMB_INF>();
            try
            {
                MEMB_INFs = _context.MEMB_INF.Where(x => x.Memb_inf_cd == Memb_inf_cd).ToList();
            }
            catch
            {

                return NotFound();
            }

            return MEMB_INFs;
        }

        [HttpGet("Phn_num={Phn_num}")]
        public async Task<ActionResult<List<MEMB_INF>>> GetMEMB_INFByP(string Phn_num)
        {
            List<MEMB_INF> MEMB_INFs = new List<MEMB_INF>();
            try
            {
                MEMB_INFs = _context.MEMB_INF.Where(x => x.Phn_num == Phn_num).ToList();
            }
            catch
            {

                return NotFound();
            }

            return MEMB_INFs;
        }


        // POST: api/DepositConfirm
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<MEMB_INF>> PostMEMB_INF(MEMB_INF MEMB_INFs)
        {
            List<MEMB_INF> infos = _context.MEMB_INF.Where(x => x.Phn_num == MEMB_INFs.Phn_num).ToList();
            if (infos.Count > 0) return BadRequest();

            MEMB_INF member = new MEMB_INF();
           member.Memb_inf_cd = _context.MEMB.FromSqlRaw("select GET_KEY('MEMBER') as Memb_inf_cd").FirstOrDefault().Memb_inf_cd;

            member.Phn_num = MEMB_INFs.Phn_num;
            member.Nm = MEMB_INFs.Nm;
            member.Email = MEMB_INFs.Email;
            member.Fir_inp_ddt = DateTime.Now;
            member.Las_mod_ddt = DateTime.Now;
            member.Las_mod_pers = "KIOSK";

            _context.MEMB_INF.Add(member);
            await _context.SaveChangesAsync();      

            // return CreatedAtAction("GetDepositConfirm", new { id = depositConfirm.Id }, depositConfirm);
            return CreatedAtAction("GetMEMB_INF", new { memb_inf_cd = member.Memb_inf_cd } , member);
        }


        private bool MEMB_INFExists(string Memb_inf_cd , string Pnt_bnk_inf_cd)
        {
            return _context.MEMB_INF.Any(e => e.Memb_inf_cd == Memb_inf_cd);
        }


    }



}
