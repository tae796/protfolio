using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using JoyTvApi.Models;
using JoyTvApi.Models.AgencyTotal;
using Newtonsoft.Json.Linq;

namespace JoyTvApi.Controllers.AgencyTotal
{
    [Route("api/[controller]")]
    [ApiController]
    public class CouponController : ControllerBase
    {
        private readonly JoyTvContext _context;

        public CouponController(JoyTvContext context)
        {
            _context = context;
        }

        // GET: api/DepositConfirm
        [HttpGet]
        public async Task<ActionResult<IEnumerable<COUP_INF>>> Get()
        {
            return await _context.COUP_INF.ToListAsync();
        }

        [HttpGet("Array")]
        public COUP_INF[]  GetArrayCOUP_INF()
        {
            int count = _context.COUP_INF.Count();
            COUP_INF[] result = new COUP_INF[count];
            result = _context.COUP_INF.ToArray();
            return result;
        }


        // GET: api/DepositConfirm/5
        [HttpGet("Coup_inf_cd={Coup_inf_cd}")]
        public async Task<ActionResult<List<COUP_INF>>> GetCOUP_INF(String Coup_inf_cd)
        {
            List<COUP_INF> COUP_INFs = new List<COUP_INF>();
	    try
	    {
                COUP_INFs = _context.COUP_INF.Where(x => x.Coup_inf_cd == Coup_inf_cd).ToList();
	   }
            catch {
            
                return NotFound();
            }

            return COUP_INFs;
        }

        // GET: api/DepositConfirm/5
        [HttpGet("Memb_inf_cd={Memb_inf_cd}&Pnt_bnk_inf_cd={Pnt_bnk_inf_cd}")]
        public async Task<ActionResult<List<COUP_INF>>> GetCOUP_INF(String Memb_inf_cd, string Pnt_bnk_inf_cd)
        {
            List<COUP_INF> COUP_INFs = new List<COUP_INF>();
            try
            {
                COUP_INFs = _context.COUP_INF.Where(x => x.Memb_inf_cd == Memb_inf_cd && x.Pnt_bnk_inf_cd == Pnt_bnk_inf_cd).ToList();
            }
            catch
            {

                return NotFound();
            }

            return COUP_INFs;
        }

        // GET: api/DepositConfirm/5
        [HttpGet("Coup_titl={Coup_titl}&Memb_inf_cd={Memb_inf_cd}")]
        public async Task<ActionResult<List<COUP_INF>>> GetCOUP_INFby(String Coup_titl, String Memb_inf_cd)
        {
            List<COUP_INF> COUP_INFs = new List<COUP_INF>();
            try
            {
                COUP_INFs = _context.COUP_INF.Where(x => x.Coup_titl == Coup_titl && x.Memb_inf_cd == Memb_inf_cd).ToList();
            }
            catch
            {

                return NotFound();
            }

            return COUP_INFs;
        }

        [HttpGet("phn_num={Phn_num}")]
        public async Task<ActionResult<List<COUP_INF>>> GetCAMP_INF(String Phn_num)
        {
            List<COUP_INF> COUP_INFs = new List<COUP_INF>();
            string memb_inf_Cd;

            MEMB_INF membinfos = new MEMB_INF();
            try
            {
                membinfos = _context.MEMB_INF.Where(x => x.Phn_num == Phn_num).FirstOrDefault();
                memb_inf_Cd = membinfos.Memb_inf_cd;
                COUP_INFs = _context.COUP_INF.Where(x => x.Memb_inf_cd == memb_inf_Cd).ToList();
            }
            catch
            {

                return NotFound();
            }

            return COUP_INFs;
        }


        // PUT: api/DepositConfirm/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("Coup_inf_cd={Coup_inf_cd}")]
        public async Task<IActionResult> PutCOUP_INF(string Coup_inf_cd, COUP_INF coupons)
        {
            if (Coup_inf_cd != coupons.Coup_inf_cd)
            {
                return BadRequest();
            }

            _context.Entry(coupons).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!COUP_INFExists(Coup_inf_cd))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/DepositConfirm
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<COUP_INF>> PostCOUP_INF(COUP_INF COUP_INFs)
        {
            List<COUP_INF> couponinfos = _context.COUP_INF.Where(x => x.Coup_inf_cd == COUP_INFs.Coup_inf_cd).ToList();
            if (couponinfos.Count > 0) return BadRequest();



            COUP_INF infos = _context.COUP_INF.OrderBy(x => x.Coup_inf_cd).LastOrDefault();
            COUP_INF coupon = new COUP_INF();
            coupon.Coup_inf_cd = _context.COUP_INF2.FromSqlRaw("select GET_KEY('COUPON') as COUP_INF_CD").FirstOrDefault().Coup_inf_cd;

            _context.COUP_INF.Add(coupon);
            await _context.SaveChangesAsync();



            // return CreatedAtAction("GetDepositConfirm", new { id = depositConfirm.Id }, depositConfirm);
            return CreatedAtAction("GetCOUP_INF", new { Coup_inf_cd = coupon.Coup_inf_cd } , coupon);
        }

        [HttpPost("/api/[Controller]/AllCOUP_INF/Memb_inf_cd={Memb_inf_cd}")]
        public async Task<ActionResult<COUP_INF[]>> PostAllCOUP_INF(List<CAMP_INF> COUP_INFinfo, string Memb_inf_cd)
        {
            List<COUP_INF> result = new List<COUP_INF>();
            List<COUP_INF> couponinfos = new List<COUP_INF>();
            //List<CAMP_INF> COUP_INFinfo = new List<CAMP_INF>();
            //COUP_INFinfo = _context.CAMP_INF.Where(x => x.Expr_yn == "N").ToList();
            int couponcount;
            COUP_INF tmp = new COUP_INF();
            
            couponcount = COUP_INFinfo.Count;
            for (int i = 0; i < couponcount; i++)
            {
                COUP_INF coupon = new COUP_INF();
                tmp = _context.COUP_INF.Where(x => x.Coup_titl == COUP_INFinfo[i].Coup_titl && x.Memb_inf_cd == Memb_inf_cd).FirstOrDefault();
                if (tmp == null)
                {
                    coupon.Coup_inf_cd = _context.COUP_INF2.FromSqlRaw("select GET_KEY('COUPON') as COUP_INF_CD").FirstOrDefault().Coup_inf_cd;

                    coupon.Coup_titl = COUP_INFinfo[i].Coup_titl;
                    coupon.Pnt_bnk_inf_cd = COUP_INFinfo[i].Pnt_bnk_inf_cd;
                    coupon.Memb_inf_cd = Memb_inf_cd;
                    coupon.Isue_ddt = DateTime.Now;
                    coupon.Expr_dd = COUP_INFinfo[i].Expr_dd;
                    coupon.Use_yn = "N";
                    coupon.Disp_yn = "Y";

                    result.Add(coupon);
                    _context.COUP_INF.Add(coupon);
                    await _context.SaveChangesAsync();

                    BNK_MEMB_INF bankInfo = new BNK_MEMB_INF();
                    BNK_MEMB_INF tmp2 = new BNK_MEMB_INF();

                    bankInfo = _context.BNK_MEMB_INF.Where(x => x.Pnt_bnk_inf_cd == coupon.Pnt_bnk_inf_cd && x.Memb_inf_cd == Memb_inf_cd).FirstOrDefault();
                    if (bankInfo == null)
                    {

                        tmp2.Memb_inf_cd = Memb_inf_cd;
                        tmp2.Pnt_bnk_inf_cd = coupon.Pnt_bnk_inf_cd;
                        tmp2.Tot_coup = 1;
                        tmp2.Fir_inp_ddt = DateTime.Now;
                        tmp2.Las_mod_ddt = DateTime.Now;
                        tmp2.Fir_inp_pers = "KIOSK";
                        tmp2.Las_grd_mod_pers = "KIOSK";
                        tmp2.Las_mod_pers = "KIOSK";
                        tmp2.Las_grd_mod_ddt = DateTime.Now;
                        tmp2.Memb_Grd_cd = "MG2013112709340800002";

                        _context.BNK_MEMB_INF.Add(tmp2);
                        await _context.SaveChangesAsync();
                        CreatedAtAction("GetBNK_MEMB_INF", new { Memb_inf_cd = tmp2.Memb_inf_cd }, tmp2);
                    }
                    else
                    {

                        bankInfo.Tot_coup = bankInfo.Tot_coup + 1;
                        await _context.SaveChangesAsync();
                    }



                }
                else
                {

                }
            }

            int count = result.Count();
            COUP_INF[] coupon1 = new COUP_INF[count];
            coupon1 = result.ToArray();

            // return CreatedAtAction("GetArrayCOUP_INF", new { Coup_inf_cd = coupon.Coup_inf_cd }, result.ToArray());
            return result.ToArray();
        }



        [HttpGet("CouponCount/Pnt_bnk_inf_cd={Pnt_bnk_inf_cd}&Datetime={dateTime}")]
        public IActionResult GetCouponcount(String Pnt_bnk_inf_cd, DateTime dateTime)
        {
            List<COUP_INF> memberInfos = new List<COUP_INF>();
            string date = dateTime.ToString("d");

            return Ok(new { results = _context.COUP_INF.Where(x => x.Pnt_bnk_inf_cd == Pnt_bnk_inf_cd && x.Use_yn == "Y" && x.Use_ddt.Value == dateTime.Date).ToList().Count() });
        }

        [HttpGet("UserCount/Pnt_bnk_inf_cd={Pnt_bnk_inf_cd}&Datetime={dateTime}")]
        public IActionResult GetUsercount(String Pnt_bnk_inf_cd, DateTime dateTime)
        {
            List<COUP_INF> memberInfos = new List<COUP_INF>();
            string date = dateTime.ToString("d");
            int usercount = 0;
            try
            {
                memberInfos = _context.COUP_INF.Where(x => x.Pnt_bnk_inf_cd == Pnt_bnk_inf_cd && x.Use_yn == "Y" && x.Use_ddt.Value == dateTime.Date).ToList();
                usercount = memberInfos.GroupBy(x => x.Memb_inf_cd).ToList().Count();
            }
            catch
            {

            }


            return Ok(new { results = usercount });

        }

        [HttpPost("campaign_id={campaign_id}&Memb_inf_cd={Memb_inf_cd}")]
        public async Task<ActionResult<COUP_INF>> PostCoupon(int campaign_id, string Memb_inf_cd)
        {
            COUP_INF coupon = new COUP_INF();
            CAMP_INF couponInfos = _context.CAMP_INF.Where(x => x.Camp_inf_cd == campaign_id).FirstOrDefault();
            if (couponInfos == null) return BadRequest();

            coupon.Coup_inf_cd = _context.COUP_INF2.FromSqlRaw("select GET_KEY('COUPON') as COUP_INF_CD").FirstOrDefault().Coup_inf_cd;


            coupon.Coup_titl = couponInfos.Coup_titl;
            coupon.Pnt_bnk_inf_cd = couponInfos.Pnt_bnk_inf_cd;
            coupon.Memb_inf_cd = Memb_inf_cd;
            coupon.Isue_ddt = DateTime.Now;
            coupon.Expr_dd = couponInfos.Expr_dd;
            coupon.Use_yn = "N";

            _context.COUP_INF.Add(coupon);
            await _context.SaveChangesAsync();

            BNK_MEMB_INF bankInfo = new BNK_MEMB_INF();
            BNK_MEMB_INF tmp2 = new BNK_MEMB_INF();

            bankInfo = _context.BNK_MEMB_INF.Where(x => x.Pnt_bnk_inf_cd == coupon.Pnt_bnk_inf_cd && x.Memb_inf_cd == Memb_inf_cd).FirstOrDefault();
            if (bankInfo == null)
            {

                tmp2.Memb_inf_cd = Memb_inf_cd;
                tmp2.Pnt_bnk_inf_cd = coupon.Pnt_bnk_inf_cd;
                tmp2.Tot_coup = 1;
                tmp2.Fir_inp_ddt = DateTime.Now;
                tmp2.Las_mod_ddt = DateTime.Now;
                _context.BNK_MEMB_INF.Add(tmp2);
                await _context.SaveChangesAsync();
                CreatedAtAction("GetBankInfo", new { Memb_inf_cd = tmp2.Memb_inf_cd }, tmp2);
            }
            else
            {

                bankInfo.Tot_coup = bankInfo.Tot_coup + 1;
                await _context.SaveChangesAsync();
            }


            return CreatedAtAction("GetCoupon", new { Coup_inf_cd = coupon.Coup_inf_cd }, coupon);
        }

        [HttpPut("Coup_inf_cd={coup_inf_cd}")]
        public async Task<IActionResult> UseCoupon(string coup_inf_cd)
        {
            COUP_INF infos = new COUP_INF();
            infos = _context.COUP_INF.Where(x => x.Coup_inf_cd == coup_inf_cd).FirstOrDefault();
            if (infos == null) return Ok(new { results = 0 });
            else
            {
                if (infos.Use_yn == "Y")
                {
                    return Ok(new { results = 2 });
                }
                else
                {
                    infos.Use_yn = "Y";
                    infos.Use_ddt = DateTime.Now;
                }
            }

            await _context.SaveChangesAsync();
            return Ok(new { results = 1 });
        }

        private bool COUP_INFExists(string Coup_inf_cd)
        {
            return _context.COUP_INF.Any(e => e.Coup_inf_cd == Coup_inf_cd);
        }
        
    }
}