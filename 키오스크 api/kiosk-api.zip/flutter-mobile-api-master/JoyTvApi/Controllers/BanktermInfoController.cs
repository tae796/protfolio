using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using JoyTvApi.Models;
using JoyTvApi.Models.AgencyTotal;

namespace JoyTvApi.Controllers.AgencyTotal
{
    [Route("api/[controller]")]
    [ApiController]
    public class BanktermInfoController : ControllerBase
    {
        private readonly JoyTvContext _context;

        public BanktermInfoController(JoyTvContext context)
        {
            _context = context;
        }

        // GET: api/DepositConfirm
        [HttpGet]
        public async Task<ActionResult<IEnumerable<BNK_TERM_INF>>> GetBanktermInfo()
        {
            return await _context.BNK_TERM_INF.ToListAsync();
        }

        // GET: api/DepositConfirm/5
        [HttpGet("sto_inf_cd={sto_inf_cd}")]
        public async Task<ActionResult<List<BNK_TERM_INF>>> GetBanktermInfo(string sto_inf_cd)
        {
            List<BNK_TERM_INF> BanktermInfos = new List<BNK_TERM_INF>();
	    try
	    {
                BanktermInfos = _context.BNK_TERM_INF.Where(x => x.Sto_inf_cd == sto_inf_cd).ToList();
	   }
            catch {
            
                return NotFound();
            }

            return BanktermInfos;
        }


        // POST: api/DepositConfirm
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<BNK_TERM_INF>> PostBanktermInfo(BNK_TERM_INF BanktermInfos)
        {
            List<BNK_TERM_INF> infos = _context.BNK_TERM_INF.Where(x => x.Rent_term_inf_cd == BanktermInfos.Rent_term_inf_cd).ToList();
            if (infos.Count > 0) return BadRequest();
            _context.BNK_TERM_INF.Add(BanktermInfos);
            await _context.SaveChangesAsync();      

            // return CreatedAtAction("GetDepositConfirm", new { id = depositConfirm.Id }, depositConfirm);
            return CreatedAtAction("GetBanktermInfo", new { Rent_term_inf_cd = BanktermInfos.Rent_term_inf_cd } , BanktermInfos);
        }


        private bool BanktermInfoExists(string Rent_term_inf_cd)
        {
            return _context.BNK_TERM_INF.Any(e => e.Rent_term_inf_cd == Rent_term_inf_cd);
        }
        
    }
}