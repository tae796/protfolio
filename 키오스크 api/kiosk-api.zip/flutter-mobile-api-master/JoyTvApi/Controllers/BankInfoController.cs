using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using JoyTvApi.Models;
using JoyTvApi.Models.AgencyTotal;
using Newtonsoft.Json;

namespace JoyTvApi.Controllers.AgencyTotal
{
    [Route("api/[controller]")]
    [ApiController]
    public class BankInfoController : ControllerBase
    {
        private readonly JoyTvContext _context;

        public BankInfoController(JoyTvContext context)
        {
            _context = context;
        }

        // GET: api/DepositConfirm
        [HttpGet]
        public async Task<ActionResult<IEnumerable<BNK_MEMB_INF>>> GetBNK_MEMB_INF()
        {
            return await _context.BNK_MEMB_INF.ToListAsync();
        }

        [HttpGet("mobile")]
        public IActionResult GetBankInfo()
        {
            List<BNK_MEMB_INF> bankinfos = new List<BNK_MEMB_INF>();
            bankinfos = _context.BNK_MEMB_INF.ToList();

            return Ok(new { results = _context.BNK_MEMB_INF.ToList() });
        }

        [HttpGet("{Memb_inf_cd},{Pnt_bnk_inf_cd}")]
        public IActionResult GetBankinfo(String Memb_inf_cd, String Pnt_bnk_inf_cd)
        {
            List<BNK_MEMB_INF> bankInfos = new List<BNK_MEMB_INF>();

            bankInfos = _context.BNK_MEMB_INF.Where(x => x.Memb_inf_cd == Memb_inf_cd && x.Pnt_bnk_inf_cd == Pnt_bnk_inf_cd).ToList();

            string json = JsonConvert.SerializeObject(new { results = bankInfos });

            return Ok(new { results = bankInfos });
        }


        // GET: api/DepositConfirm/5
        [HttpGet("Memb_inf_cd={Memb_inf_cd}&Pnt_bnk_inf_cd={Pnt_bnk_inf_cd}")]
        public async Task<ActionResult<List<BNK_MEMB_INF>>> GetBNK_MEMB_INF(string Memb_inf_cd, string Pnt_bnk_inf_cd)
        {
            List<BNK_MEMB_INF> BNK_MEMB_INFs = new List<BNK_MEMB_INF>();
	    try
	    {
                BNK_MEMB_INFs = _context.BNK_MEMB_INF.Where(x => x.Memb_inf_cd == Memb_inf_cd && x.Pnt_bnk_inf_cd == Pnt_bnk_inf_cd).ToList();
	   }
            catch {
            
                return NotFound();
            }

            return BNK_MEMB_INFs;
        }

        [HttpGet("{Memb_inf_cd}")]
        public IActionResult GetBankinfo(String Memb_inf_cd)
        {
            List<BNK_MEMB_INF> bankInfos = new List<BNK_MEMB_INF>();
            List<BankStoInfo> bankstoinfos = new List<BankStoInfo>();
            bankInfos = _context.BNK_MEMB_INF.Where(x => x.Memb_inf_cd == Memb_inf_cd).ToList();

            int bankcount = bankInfos.Count();
            for (int i = 0; i < bankcount; i++)
            {
                BankStoInfo tmp = new BankStoInfo();
                STO_INF sto_tmp = new STO_INF();
                BNK_TERM_INF change = new BNK_TERM_INF();
                change = _context.BNK_TERM_INF.Where(x => x.Pnt_bnk_inf_cd == bankInfos[i].Pnt_bnk_inf_cd).FirstOrDefault();

                sto_tmp = _context.STO_INF.Where(x => x.Sto_inf_cd == change.Sto_inf_cd).FirstOrDefault();

                tmp.Memb_inf_cd = bankInfos[i].Memb_inf_cd;
                tmp.Pnt_bnk_inf_cd = bankInfos[i].Pnt_bnk_inf_cd;
                tmp.Memb_Grd_cd = bankInfos[i].Memb_Grd_cd;
                tmp.Mast_pnt = bankInfos[i].Mast_pnt;
                tmp.Tot_pnt = bankInfos[i].Tot_pnt;
                tmp.Tot_buy = bankInfos[i].Tot_buy;
                tmp.Tot_vist = bankInfos[i].Tot_vist;
               // tmp.Tot_coup = bankInfos[i].Tot_coup;
                tmp.Las_grd_mod_ddt = bankInfos[i].Las_grd_mod_ddt;
                tmp.Las_grd_mod_pers = bankInfos[i].Las_grd_mod_pers;
                tmp.Fir_inp_pers = bankInfos[i].Fir_inp_pers;
                tmp.Fir_inp_ddt = bankInfos[i].Fir_inp_ddt;
                tmp.Las_mod_pers = bankInfos[i].Las_mod_pers;
                tmp.Las_mod_ddt = bankInfos[i].Las_mod_ddt;
                tmp.Sto_inf_cd = sto_tmp.Sto_inf_cd;
                tmp.Sto_nm = sto_tmp.Sto_nm;

                bankstoinfos.Add(tmp);

            }

            return Ok(new { results = bankstoinfos });
        }



        // POST: api/DepositConfirm
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<BNK_MEMB_INF>> PostBNK_MEMB_INF(BNK_MEMB_INF BNK_MEMB_INFs)
        {
            List<BNK_MEMB_INF> infos = _context.BNK_MEMB_INF.Where(x => x.Memb_inf_cd == BNK_MEMB_INFs.Memb_inf_cd && x.Pnt_bnk_inf_cd == BNK_MEMB_INFs.Pnt_bnk_inf_cd).ToList();
            if (infos.Count > 0) return BadRequest();
            _context.BNK_MEMB_INF.Add(BNK_MEMB_INFs);
            await _context.SaveChangesAsync();      

            // return CreatedAtAction("GetDepositConfirm", new { id = depositConfirm.Id }, depositConfirm);
            return CreatedAtAction("GetBNK_MEMB_INF", new { memb_inf_cd = BNK_MEMB_INFs.Memb_inf_cd } , BNK_MEMB_INFs);
        }


        private bool BNK_MEMB_INFExists(string Memb_inf_cd , string Pnt_bnk_inf_cd)
        {
            return _context.BNK_MEMB_INF.Any(e => e.Memb_inf_cd == Memb_inf_cd && e.Pnt_bnk_inf_cd == Pnt_bnk_inf_cd);
        }
        
    }
}