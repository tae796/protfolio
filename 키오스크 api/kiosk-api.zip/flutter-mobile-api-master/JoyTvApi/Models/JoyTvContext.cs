using Microsoft.EntityFrameworkCore;

namespace JoyTvApi.Models
{
    public class JoyTvContext : DbContext
    {
        public string DbPath { get; private set; } 
        
        public JoyTvContext(DbContextOptions<JoyTvContext> options)
            // : base(options)
        {
            DbPath = "server=dbwriter.flutterup.net;database=flutter;user=root;password=zzVNIM3Mqw44sUVa;charset=utf8;SslMode=none";
        }
        
        protected override void OnConfiguring(DbContextOptionsBuilder options)
            => options.UseMySql(DbPath, ServerVersion.AutoDetect(DbPath));

	    public DbSet<AgencyTotal.WAITING_INF> WAITING_INF { get; set;}
        public DbSet<AgencyTotal.CAMP_INF> CAMP_INF { get; set; }
        public DbSet<AgencyTotal.COUP_INF> COUP_INF { get; set; }
        public DbSet<AgencyTotal.COUP_INF2> COUP_INF2 { get; set; }
        public DbSet<AgencyTotal.BNK_MEMB_INF> BNK_MEMB_INF { get; set; }
        public DbSet<AgencyTotal.BNK_TERM_INF> BNK_TERM_INF { get; set; }
        public DbSet<AgencyTotal.MEMB_INF> MEMB_INF { get; set; }
        public DbSet<AgencyTotal.MEMB> MEMB { get; set; }
        public DbSet<AgencyTotal.STO_INF> STO_INF { get; set; }
        public DbSet<AgencyTotal.BankStoInfo> BankStoInfo { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
	{
		modelBuilder.Entity<AgencyTotal.WAITING_INF>()
		.HasIndex(p => new{p.sto_inf_cd, p.Waiting_num})
		.IsUnique(true);

        modelBuilder.Entity<AgencyTotal.COUP_INF>()
       .Property(b => b.Use_yn)
       .HasDefaultValue('N');
        
        modelBuilder.Entity<AgencyTotal.BNK_MEMB_INF>()
        .HasKey(p => new { p.Memb_inf_cd, p.Pnt_bnk_inf_cd });

        modelBuilder.Entity<AgencyTotal.BankStoInfo>()
        .HasKey(p => new { p.Memb_inf_cd, p.Pnt_bnk_inf_cd });

        }

    
        





    }
}
