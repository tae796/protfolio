using Microsoft.EntityFrameworkCore;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JoyTvApi.Models.AgencyTotal
{
    // 입금확인
    public class WAITING_INF
    {
        public DateTime? Date { get; set; }

        public string Phn_num { get; set; }
        
        public string sto_inf_cd { get; set; }
        
        public int Id { get; set; }
	
		public int Waiting_num { get; set;}
    }
}
