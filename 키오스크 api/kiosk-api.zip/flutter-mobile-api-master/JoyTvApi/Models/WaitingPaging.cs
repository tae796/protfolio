using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JoyTvApi.Models.AgencyTotal
{
    // 입금확인
    public class WaitingPaging
    {

		public int CurrentPage { get; set; }
        public int TotalPage { get; set; }
        public int TotalCount { get; set; }

        public List<WAITING_INF> list { get; set;}
    }
}
