package pokas.web.staticInfo;

import org.springframework.stereotype.Component;

@Component
public class Configuration {
	public static final int NAVI_COUNT_PER_PAGE = 8;
	public static final int RECORD_COUNT_PER_PAGE = 8;
}