$(document).ready(function(){
  /*  var review_arr = [
        ["", "제목란", "Lorem ipsum dolor sit amet, consectetur adipisicing elit."],
        ["", "제목란", "Lorem ipsum dolor sit amet, consectetur adipisicing elit."],
        ["", "제목란", "Lorem ipsum dolor sit amet, consectetur adipisicing elit."],
        ["", "제목란", "Lorem ipsum dolor sit amet, consectetur adipisicing elit."],
        ["", "제목란", "Lorem ipsum dolor sit amet, consectetur adipisicing elit."],
        ["", "제목란", "Lorem ipsum dolor sit amet, consectetur adipisicing elit."],
        ["", "제목란", "Lorem ipsum dolor sit amet, consectetur adipisicing elit."],
        ["", "제목란", "Lorem ipsum dolor sit amet, consectetur adipisicing elit."],
    ];

    var review_cont = `
        <div class="box">
            <div class="img"></div>
            <h2>제목란</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
        </div>
    `

    for(i=0; i<review_arr.length; i++){
        $("#review .cont .review").append(review_cont);
    }*/
});