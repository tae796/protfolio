$(document).ready(function(){
    var review_arr = [
        ["", "제목란", "Lorem ipsum dolor sit amet, consectetur adipisicing elit."],
        ["", "제목란", "Lorem ipsum dolor sit amet, consectetur adipisicing elit."],
        ["", "제목란", "Lorem ipsum dolor sit amet, consectetur adipisicing elit."],
        ["", "제목란", "Lorem ipsum dolor sit amet, consectetur adipisicing elit."],
        ["", "제목란", "Lorem ipsum dolor sit amet, consectetur adipisicing elit."],
        ["", "제목란", "Lorem ipsum dolor sit amet, consectetur adipisicing elit."],
        ["", "제목란", "Lorem ipsum dolor sit amet, consectetur adipisicing elit."],
        ["", "제목란", "Lorem ipsum dolor sit amet, consectetur adipisicing elit."],
    ];

    var review_cont = `
        <div class="box">
            <a href="./review_cust.html">
            <div class="img"></div>
            <h2>제목란</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>
            </a>
        </div>
    `

    for(i=0; i<review_arr.length; i++){
        $("#review .cont .review").append(review_cont);
    }
});